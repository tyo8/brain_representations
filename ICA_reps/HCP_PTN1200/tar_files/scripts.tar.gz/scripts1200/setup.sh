SUBJECTS=/vols/Scratch/HCP/rfMRI/subjects1200
SCRATCH=/vols/Data/HCP/Phase2/group1200
FMRIB=/vols/Data/HCP/Phase2/scripts1200

BATCH=3T_HCP1200_MSMAll

